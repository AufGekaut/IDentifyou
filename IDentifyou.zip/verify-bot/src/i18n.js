/**
 * i18n.js — Internationalization (English / German)
 * Default language: English
 * Change per-guild with /language
 */

const STRINGS = {
  en: {
    // ── Setup ────────────────────────────────────────────────────────────────
    setup_done_title:        '✅ Setup complete!',
    setup_role_created:      '✅ Role **{name}** created',
    setup_role_existing:     '✅ Using existing role {role}',
    setup_channel_created:   '✅ Channel **#{name}** created',
    setup_channel_existing:  '✅ Using existing **#{name}** channel',
    setup_locked:            '🔒 Locked **{count}** channel(s) — only Verified can see them',
    setup_field_panel:       '📌 Verify Panel',
    setup_field_verified:    '🟢 Verified Role',
    setup_field_unverified:  '🔴 Unverified Role',
    setup_field_log:         '📋 Log Channel',
    setup_no_log:            'None',

    // ── Reset ────────────────────────────────────────────────────────────────
    reset_title:             '🔄 Setup reset',
    reset_desc:              'Verification config cleared. Run `/setup` to configure again.\n\n*Channels and roles were not deleted — remove them manually if needed.*',

    // ── Status ───────────────────────────────────────────────────────────────
    status_title:            '📋 Verification Status',
    status_not_found:        '⚠️ Not found',
    status_field_channel:    '📌 Verify Channel',
    status_field_verified:   '🟢 Verified Role',
    status_field_unverified: '🔴 Unverified Role',
    status_field_log:        '📋 Log Channel',
    status_field_color:      '🎨 Embed Color',
    status_field_button:     '🔘 Button Style',
    status_no_setup:         '❌ No setup found. Run `/setup` first.',

    // ── Stats ────────────────────────────────────────────────────────────────
    stats_title:             '📊 Verification Statistics',
    stats_total:             '✅ Total Verified',
    stats_failed:            '❌ Failed Attempts',
    stats_rate:              '🎯 Success Rate',
    stats_active:            '⏳ Active CAPTCHA Sessions',
    stats_last:              '🕐 Last Verified',
    stats_last_none:         '—',
    stats_footer:            'Data persisted in db.json',

    // ── Language ─────────────────────────────────────────────────────────────
    lang_set:                '🌐 Language set to **English**.',
    lang_already:            '🌐 Language is already set to **English**.',
    lang_desc_en:            'English',
    lang_desc_de:            'German / Deutsch',

    // ── Verify Flow ──────────────────────────────────────────────────────────
    verify_not_setup:        '⚠️ Verification is not set up. Ask an admin to run `/setup`.',
    verify_already:          '✅ You are already verified!',
    verify_active_session:   '⏳ You already have an active CAPTCHA. Check your DMs or click the answer button.',
    verify_dm_sent:          '📬 A CAPTCHA has been sent to your DMs!',
    verify_dm_failed:        '📩 Could not send DM. Here is your CAPTCHA:',
    verify_no_session:       '❌ No active CAPTCHA session. Please click the verify button in the server.',
    verify_success:          '✅ **Successfully verified!** Welcome to the server!',
    verify_fail:             '❌ Wrong CAPTCHA. Here is a new one.',
    verify_fail_title:       '❌ Wrong Answer — Try Again',
    verify_timeout:          '⏰ CAPTCHA expired. Please click the verify button again.',
    verify_max_attempts:     '🚫 Too many wrong attempts. Please try again later.',
    verify_attempts_left:    '\n🎯 Attempts remaining: **{n}**',
    verify_expires:          '\n⏱️ Expires',
    verify_guild_error:      '❌ Guild not found.',
    verify_config_error:     '❌ Config missing.',
    verify_member_error:     '❌ Could not find you in the server.',
    verify_role_error:       '❌ Could not assign role. Check bot permissions.',
    verify_generic_error:    '❌ An error occurred.',

    // ── CAPTCHA Embed ────────────────────────────────────────────────────────
    captcha_title:           '🔐 CAPTCHA Verification',
    captcha_desc:            'Type the characters shown in the image below.',
    captcha_attempts:        '\n🎯 Attempts remaining: **{n}**',
    captcha_btn_answer:      '✏️ Enter Answer',
    captcha_modal_title:     'Enter the CAPTCHA',
    captcha_input_label:     'CAPTCHA Answer (not case-sensitive)',
    captcha_input_ph:        'e.g. AB3X7Z',

    // ── Panel Embed ──────────────────────────────────────────────────────────
    panel_title:             '🔐 Server Verification',
    panel_desc:              'Click the button below to verify yourself and gain access to the server.',
    panel_footer:            'Verification powered by IDentifyou',
    panel_btn:               '✅ Verify me',

    // ── Log ──────────────────────────────────────────────────────────────────
    log_title:               '✅ Member Verified',
    log_user:                'User',
    log_id:                  'ID',
    log_attempts:            'Attempts',
    log_total:               '📊 Total verified (this server)',
  },

  de: {
    // ── Setup ────────────────────────────────────────────────────────────────
    setup_done_title:        '✅ Einrichtung abgeschlossen!',
    setup_role_created:      '✅ Rolle **{name}** erstellt',
    setup_role_existing:     '✅ Vorhandene Rolle {role} wird verwendet',
    setup_channel_created:   '✅ Channel **#{name}** erstellt',
    setup_channel_existing:  '✅ Vorhandener **#{name}** Channel wird verwendet',
    setup_locked:            '🔒 **{count}** Channel gesperrt — nur Verified kann diese sehen',
    setup_field_panel:       '📌 Verify-Panel',
    setup_field_verified:    '🟢 Verified-Rolle',
    setup_field_unverified:  '🔴 Unverified-Rolle',
    setup_field_log:         '📋 Log-Channel',
    setup_no_log:            'Keiner',

    // ── Reset ────────────────────────────────────────────────────────────────
    reset_title:             '🔄 Einrichtung zurückgesetzt',
    reset_desc:              'Verifizierungs-Konfiguration gelöscht. Führe `/setup` aus, um neu zu konfigurieren.\n\n*Channels und Rollen wurden nicht gelöscht — entferne sie bei Bedarf manuell.*',

    // ── Status ───────────────────────────────────────────────────────────────
    status_title:            '📋 Verifizierungs-Status',
    status_not_found:        '⚠️ Nicht gefunden',
    status_field_channel:    '📌 Verify-Channel',
    status_field_verified:   '🟢 Verified-Rolle',
    status_field_unverified: '🔴 Unverified-Rolle',
    status_field_log:        '📋 Log-Channel',
    status_field_color:      '🎨 Embed-Farbe',
    status_field_button:     '🔘 Button-Stil',
    status_no_setup:         '❌ Keine Einrichtung gefunden. Führe `/setup` aus.',

    // ── Stats ────────────────────────────────────────────────────────────────
    stats_title:             '📊 Verifizierungs-Statistiken',
    stats_total:             '✅ Gesamt verifiziert',
    stats_failed:            '❌ Fehlgeschlagene Versuche',
    stats_rate:              '🎯 Erfolgsquote',
    stats_active:            '⏳ Aktive CAPTCHA-Sessions',
    stats_last:              '🕐 Zuletzt verifiziert',
    stats_last_none:         '—',
    stats_footer:            'Daten gespeichert in db.json',

    // ── Language ─────────────────────────────────────────────────────────────
    lang_set:                '🌐 Sprache auf **Deutsch** gesetzt.',
    lang_already:            '🌐 Sprache ist bereits auf **Deutsch** eingestellt.',
    lang_desc_en:            'Englisch / English',
    lang_desc_de:            'Deutsch',

    // ── Verify Flow ──────────────────────────────────────────────────────────
    verify_not_setup:        '⚠️ Verifizierung ist nicht eingerichtet. Bitte einen Admin, `/setup` auszuführen.',
    verify_already:          '✅ Du bist bereits verifiziert!',
    verify_active_session:   '⏳ Du hast bereits ein aktives CAPTCHA. Schau in deine DMs oder klicke den Antwort-Button.',
    verify_dm_sent:          '📬 Ein CAPTCHA wurde dir per DM gesendet!',
    verify_dm_failed:        '📩 DM konnte nicht gesendet werden. Hier ist dein CAPTCHA:',
    verify_no_session:       '❌ Keine aktive CAPTCHA-Session. Klicke den Verify-Button im Server.',
    verify_success:          '✅ **Erfolgreich verifiziert!** Willkommen auf dem Server!',
    verify_fail:             '❌ Falsches CAPTCHA. Hier ist ein neues.',
    verify_fail_title:       '❌ Falsche Antwort — Nochmal versuchen',
    verify_timeout:          '⏰ CAPTCHA abgelaufen. Klicke erneut auf den Verify-Button.',
    verify_max_attempts:     '🚫 Zu viele Fehlversuche. Bitte versuche es später erneut.',
    verify_attempts_left:    '\n🎯 Verbleibende Versuche: **{n}**',
    verify_expires:          '\n⏱️ Läuft ab',
    verify_guild_error:      '❌ Server nicht gefunden.',
    verify_config_error:     '❌ Konfiguration fehlt.',
    verify_member_error:     '❌ Du wurdest auf dem Server nicht gefunden.',
    verify_role_error:       '❌ Rolle konnte nicht vergeben werden. Prüfe die Bot-Berechtigungen.',
    verify_generic_error:    '❌ Ein Fehler ist aufgetreten.',

    // ── CAPTCHA Embed ────────────────────────────────────────────────────────
    captcha_title:           '🔐 CAPTCHA-Verifizierung',
    captcha_desc:            'Gib die Zeichen aus dem Bild unten ein.',
    captcha_attempts:        '\n🎯 Verbleibende Versuche: **{n}**',
    captcha_btn_answer:      '✏️ Antwort eingeben',
    captcha_modal_title:     'CAPTCHA eingeben',
    captcha_input_label:     'CAPTCHA-Antwort (Groß-/Kleinschreibung egal)',
    captcha_input_ph:        'z.B. AB3X7Z',

    // ── Panel Embed ──────────────────────────────────────────────────────────
    panel_title:             '🔐 Server-Verifizierung',
    panel_desc:              'Klicke den Button unten, um dich zu verifizieren und Zugang zum Server zu erhalten.',
    panel_footer:            'Verifizierung powered by IDentifyou',
    panel_btn:               '✅ Verifizieren',

    // ── Log ──────────────────────────────────────────────────────────────────
    log_title:               '✅ Mitglied verifiziert',
    log_user:                'Nutzer',
    log_id:                  'ID',
    log_attempts:            'Versuche',
    log_total:               '📊 Gesamt verifiziert (dieser Server)',
  },
};

/**
 * Get a translated string for a guild.
 * Replaces {key} placeholders with values from `vars`.
 * Falls back to English if key missing in target lang.
 */
function t(guildId, key, vars = {}) {
  const config = require('./db').getConfig(guildId);
  const lang   = config?.language || 'en';
  const strings = STRINGS[lang] || STRINGS.en;
  let str = strings[key] ?? STRINGS.en[key] ?? key;

  for (const [k, v] of Object.entries(vars)) {
    str = str.replaceAll(`{${k}}`, v);
  }
  return str;
}

/** All supported languages */
const LANGUAGES = Object.keys(STRINGS);

module.exports = { t, LANGUAGES, STRINGS };
