const { createCanvas } = require('canvas');

const CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // removed confusing chars (0,O,1,I)

/**
 * Generates a random captcha code
 */
function generateCode(length = parseInt(process.env.CAPTCHA_LENGTH) || 6) {
  let code = '';
  for (let i = 0; i < length; i++) {
    code += CHARS[Math.floor(Math.random() * CHARS.length)];
  }
  return code;
}

/**
 * Renders captcha text onto a canvas and returns a Buffer (PNG)
 */
function renderCaptcha(code) {
  const width = 280;
  const height = 100;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  // Background gradient
  const bg = ctx.createLinearGradient(0, 0, width, height);
  bg.addColorStop(0, '#1a1a2e');
  bg.addColorStop(1, '#16213e');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, width, height);

  // Noise dots
  for (let i = 0; i < 200; i++) {
    ctx.beginPath();
    ctx.arc(
      Math.random() * width,
      Math.random() * height,
      Math.random() * 2,
      0,
      Math.PI * 2
    );
    ctx.fillStyle = `rgba(${rand(100,255)},${rand(100,255)},${rand(100,255)},${Math.random() * 0.5})`;
    ctx.fill();
  }

  // Noise lines
  for (let i = 0; i < 6; i++) {
    ctx.beginPath();
    ctx.moveTo(Math.random() * width, Math.random() * height);
    ctx.lineTo(Math.random() * width, Math.random() * height);
    ctx.strokeStyle = `rgba(${rand(50,200)},${rand(50,200)},${rand(50,200)},0.4)`;
    ctx.lineWidth = Math.random() * 2;
    ctx.stroke();
  }

  // Draw each character with slight rotation and offset
  const charWidth = width / (code.length + 1);
  const colors = ['#ff6b6b', '#ffd93d', '#6bcb77', '#4d96ff', '#ff922b', '#cc5de8'];

  for (let i = 0; i < code.length; i++) {
    ctx.save();
    const x = charWidth * (i + 0.8) + rand(-5, 5);
    const y = height / 2 + rand(-8, 8);
    ctx.translate(x, y);
    ctx.rotate((Math.random() - 0.5) * 0.5);
    ctx.font = `bold ${rand(34, 42)}px Arial`;
    ctx.fillStyle = colors[i % colors.length];
    ctx.shadowColor = 'rgba(0,0,0,0.8)';
    ctx.shadowBlur = 4;
    ctx.fillText(code[i], 0, 0);
    ctx.restore();
  }

  // Border
  ctx.strokeStyle = '#5865F2';
  ctx.lineWidth = 3;
  ctx.strokeRect(1, 1, width - 2, height - 2);

  return canvas.toBuffer('image/png');
}

function rand(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

module.exports = { generateCode, renderCaptcha };
