const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const db    = require('../db');
const { t } = require('../i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('status')
    .setDescription('Show current verification setup / Verifizierungs-Setup anzeigen')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const gid    = interaction.guild.id;
    const config = db.getConfig(gid);

    if (!config) {
      return interaction.reply({ content: t(gid, 'status_no_setup'), ephemeral: true });
    }

    const guild = interaction.guild;
    const vc    = guild.channels.cache.get(config.verifyChannelId);
    const vr    = guild.roles.cache.get(config.verifiedRoleId);
    const uvr   = guild.roles.cache.get(config.unverifiedRoleId);
    const lc    = config.logChannelId ? guild.channels.cache.get(config.logChannelId) : null;
    const nf    = t(gid, 'status_not_found');

    const embed = new EmbedBuilder()
      .setTitle(t(gid, 'status_title'))
      .setColor(config.embedColor || '#5865F2')
      .addFields(
        { name: t(gid, 'status_field_channel'),    value: vc  ? vc.toString()  : nf, inline: true },
        { name: t(gid, 'status_field_verified'),   value: vr  ? vr.toString()  : nf, inline: true },
        { name: t(gid, 'status_field_unverified'), value: uvr ? uvr.toString() : nf, inline: true },
        { name: t(gid, 'status_field_log'),        value: lc  ? lc.toString()  : '—', inline: true },
        { name: t(gid, 'status_field_color'),      value: config.embedColor || '#5865F2',  inline: true },
        { name: t(gid, 'status_field_button'),     value: config.btnColorKey || 'Success', inline: true },
        { name: '🌐 Language',                     value: config.language === 'de' ? '🇩🇪 Deutsch' : '🇬🇧 English', inline: true },
      );

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
