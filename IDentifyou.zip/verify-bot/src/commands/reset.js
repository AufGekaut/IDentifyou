const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const db      = require('../db');
const { t }   = require('../i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reset')
    .setDescription('Reset the verification setup / Einrichtung zurücksetzen')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const gid = interaction.guild.id;
    db.deleteConfig(gid);

    const embed = new EmbedBuilder()
      .setTitle(t(gid, 'reset_title'))
      .setDescription(t(gid, 'reset_desc'))
      .setColor('#ED4245');

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
