const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const db    = require('../db');
const { t } = require('../i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stats')
    .setDescription('Show verification statistics / Verifizierungs-Statistiken anzeigen')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const gid    = interaction.guild.id;
    const stats  = db.getStats(gid);
    const config = db.getConfig(gid);
    const raw    = db.getRawDb();

    const activeSessions = Object.values(raw.sessions).filter(
      s => s.guildId === gid && Date.now() < s.expiresAt
    ).length;

    let lastVerifiedStr = t(gid, 'stats_last_none');
    if (stats.lastVerified) {
      lastVerifiedStr = `<t:${Math.floor(stats.lastVerified.at / 1000)}:R> (<@${stats.lastVerified.userId}>)`;
    }

    const successRate = (stats.total + stats.failed) > 0
      ? ((stats.total / (stats.total + stats.failed)) * 100).toFixed(1) + '%'
      : '—';

    const embed = new EmbedBuilder()
      .setTitle(t(gid, 'stats_title'))
      .setColor(config?.embedColor || '#5865F2')
      .addFields(
        { name: t(gid, 'stats_total'),   value: `${stats.total}`,    inline: true },
        { name: t(gid, 'stats_failed'),  value: `${stats.failed}`,   inline: true },
        { name: t(gid, 'stats_rate'),    value: successRate,          inline: true },
        { name: t(gid, 'stats_active'),  value: `${activeSessions}`, inline: true },
        { name: t(gid, 'stats_last'),    value: lastVerifiedStr,      inline: false },
      )
      .setFooter({ text: t(gid, 'stats_footer') })
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
