const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
} = require('discord.js');
const db  = require('../db');
const { t } = require('../i18n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('Set up the verification system / Verifizierungs-System einrichten')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addChannelOption(o =>
      o.setName('channel')
        .setDescription('Existing verify channel (empty = auto-create)')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(false)
    )
    .addRoleOption(o =>
      o.setName('verified_role')
        .setDescription('Role after verification (empty = auto-create)')
        .setRequired(false)
    )
    .addRoleOption(o =>
      o.setName('unverified_role')
        .setDescription('Role for new members (empty = auto-create)')
        .setRequired(false)
    )
    .addStringOption(o =>
      o.setName('embed_title')
        .setDescription('Title of the verify embed')
        .setRequired(false)
    )
    .addStringOption(o =>
      o.setName('embed_description')
        .setDescription('Description of the verify embed')
        .setRequired(false)
    )
    .addStringOption(o =>
      o.setName('embed_color')
        .setDescription('Hex color (e.g. #5865F2)')
        .setRequired(false)
    )
    .addStringOption(o =>
      o.setName('button_label')
        .setDescription('Label on the verify button')
        .setRequired(false)
    )
    .addStringOption(o =>
      o.setName('button_color')
        .setDescription('Button color')
        .setRequired(false)
        .addChoices(
          { name: '🔵 Primary (Blue)',    value: 'Primary'   },
          { name: '⚪ Secondary (Grey)',  value: 'Secondary' },
          { name: '🟢 Success (Green)',   value: 'Success'   },
          { name: '🔴 Danger (Red)',      value: 'Danger'    },
        )
    )
    .addChannelOption(o =>
      o.setName('log_channel')
        .setDescription('Log channel (empty = auto-create)')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(false)
    ),

  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });

    const guild = interaction.guild;
    const me    = guild.members.me;
    const gid   = guild.id;

    let verifyChannel  = interaction.options.getChannel('channel');
    let verifiedRole   = interaction.options.getRole('verified_role');
    let unverifiedRole = interaction.options.getRole('unverified_role');
    let logChannel     = interaction.options.getChannel('log_channel');

    const status = [];

    // ── Roles ─────────────────────────────────────────────────────────────────
    if (!verifiedRole) {
      verifiedRole = guild.roles.cache.find(r => r.name === 'Verified') ||
        await guild.roles.create({ name: 'Verified', color: '#57F287', reason: 'IDentifyou setup' });
      status.push(t(gid, 'setup_role_created', { name: 'Verified' }));
    } else {
      status.push(t(gid, 'setup_role_existing', { role: verifiedRole.toString() }));
    }

    if (!unverifiedRole) {
      unverifiedRole = guild.roles.cache.find(r => r.name === 'Unverified') ||
        await guild.roles.create({ name: 'Unverified', color: '#ED4245', reason: 'IDentifyou setup' });
      status.push(t(gid, 'setup_role_created', { name: 'Unverified' }));
    } else {
      status.push(t(gid, 'setup_role_existing', { role: unverifiedRole.toString() }));
    }

    // ── Verify Channel ────────────────────────────────────────────────────────
    if (!verifyChannel) {
      verifyChannel = guild.channels.cache.find(c => c.name === 'verify' && c.type === ChannelType.GuildText);
      if (!verifyChannel) {
        verifyChannel = await guild.channels.create({
          name: 'verify',
          type: ChannelType.GuildText,
          reason: 'IDentifyou setup',
          permissionOverwrites: [
            { id: guild.id,         deny: ['SendMessages'], allow: ['ViewChannel'] },
            { id: verifiedRole.id,  deny: ['ViewChannel'] },
            { id: me.id,            allow: ['SendMessages', 'ViewChannel', 'ManageMessages'] },
          ],
        });
        status.push(t(gid, 'setup_channel_created', { name: 'verify' }));
      } else {
        status.push(t(gid, 'setup_channel_existing', { name: 'verify' }));
      }
    } else {
      status.push(t(gid, 'setup_channel_existing', { name: verifyChannel.name }));
    }

    // ── Log Channel ───────────────────────────────────────────────────────────
    if (!logChannel) {
      logChannel = guild.channels.cache.find(c => c.name === 'verify-logs' && c.type === ChannelType.GuildText);
      if (!logChannel) {
        logChannel = await guild.channels.create({
          name: 'verify-logs',
          type: ChannelType.GuildText,
          reason: 'IDentifyou setup',
          permissionOverwrites: [
            { id: guild.id,        deny: ['ViewChannel'] },
            { id: verifiedRole.id, deny: ['ViewChannel'] },
            { id: me.id,           allow: ['SendMessages', 'ViewChannel'] },
          ],
        });
        status.push(t(gid, 'setup_channel_created', { name: 'verify-logs' }));
      } else {
        status.push(t(gid, 'setup_channel_existing', { name: 'verify-logs' }));
      }
    }

    // ── Lock @everyone on channels without role overrides ─────────────────────
    let lockedCount = 0;
    for (const [, channel] of guild.channels.cache) {
      if (channel.type !== ChannelType.GuildText && channel.type !== ChannelType.GuildVoice) continue;
      if (channel.id === verifyChannel.id) continue;

      const everyoneOW   = channel.permissionOverwrites.cache.get(guild.id);
      const hasRoleOverrides = channel.permissionOverwrites.cache.some(
        o => o.id !== guild.id && o.id !== me.id
      );

      if (!hasRoleOverrides && (!everyoneOW || !everyoneOW.deny.has('ViewChannel'))) {
        await channel.permissionOverwrites.edit(guild.id,        { ViewChannel: false });
        await channel.permissionOverwrites.edit(verifiedRole.id, { ViewChannel: true  });
        lockedCount++;
      }
    }
    if (lockedCount > 0) status.push(t(gid, 'setup_locked', { count: lockedCount }));

    // ── Embed & Button ────────────────────────────────────────────────────────
    const existingConfig = db.getConfig(gid) || {};
    const embedColor  = interaction.options.getString('embed_color')       || process.env.EMBED_COLOR    || '#5865F2';
    const embedTitle  = interaction.options.getString('embed_title')       || t(gid, 'panel_title');
    const embedDesc   = interaction.options.getString('embed_description') || t(gid, 'panel_desc');
    const btnLabel    = interaction.options.getString('button_label')      || t(gid, 'panel_btn');
    const btnColorKey = interaction.options.getString('button_color')      || process.env.BUTTON_COLOR   || 'Success';

    const btnStyle = {
      Primary:   ButtonStyle.Primary,
      Secondary: ButtonStyle.Secondary,
      Success:   ButtonStyle.Success,
      Danger:    ButtonStyle.Danger,
    }[btnColorKey] ?? ButtonStyle.Success;

    const embed = new EmbedBuilder()
      .setTitle(embedTitle)
      .setDescription(embedDesc)
      .setColor(embedColor)
      .setFooter({ text: t(gid, 'panel_footer') })
      .setTimestamp();


    const btn = new ButtonBuilder()
      .setCustomId('start_verify')
      .setLabel(btnLabel)
      .setStyle(btnStyle);

    const row = new ActionRowBuilder().addComponents(btn);

    // Clear old panel messages
    try {
      const msgs = await verifyChannel.messages.fetch({ limit: 10 });
      await verifyChannel.bulkDelete(msgs).catch(() => {});
    } catch {}

    const panelMsg = await verifyChannel.send({ embeds: [embed], components: [row] });

    // ── Save config ───────────────────────────────────────────────────────────
    db.setConfig(gid, {
      ...existingConfig,
      verifyChannelId:  verifyChannel.id,
      verifiedRoleId:   verifiedRole.id,
      unverifiedRoleId: unverifiedRole.id,
      logChannelId:     logChannel?.id || null,
      panelMessageId:   panelMsg.id,
      embedColor,
      embedTitle,
      embedDesc,
      btnLabel,
      btnColorKey,
    });

    // ── Reply ─────────────────────────────────────────────────────────────────
    const doneEmbed = new EmbedBuilder()
      .setTitle(t(gid, 'setup_done_title'))
      .setColor('#57F287')
      .setDescription(status.join('\n'))
      .addFields(
        { name: t(gid, 'setup_field_panel'),      value: verifyChannel.toString(),                         inline: true },
        { name: t(gid, 'setup_field_verified'),   value: verifiedRole.toString(),                          inline: true },
        { name: t(gid, 'setup_field_unverified'), value: unverifiedRole.toString(),                        inline: true },
        { name: t(gid, 'setup_field_log'),        value: logChannel ? logChannel.toString() : t(gid, 'setup_no_log'), inline: true },
      );

    await interaction.editReply({ embeds: [doneEmbed] });
  },
};
