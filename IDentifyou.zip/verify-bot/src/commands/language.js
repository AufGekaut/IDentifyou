const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { LANGUAGES, t } = require('../i18n');
const db = require('../db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('language')
    .setDescription('Set the bot language for this server / Sprache des Bots einstellen')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption(o =>
      o.setName('lang')
        .setDescription('Language / Sprache')
        .setRequired(true)
        .addChoices(
          { name: '🇬🇧 English (default)', value: 'en' },
          { name: '🇩🇪 Deutsch / German',  value: 'de' },
        )
    ),

  async execute(interaction) {
    const chosen = interaction.options.getString('lang');
    const guildId = interaction.guild.id;
    const config  = db.getConfig(guildId);

    // Already set?
    if (config?.language === chosen) {
      return interaction.reply({
        content: t(guildId, 'lang_already'),
        ephemeral: true,
      });
    }

    // Save language in config
    db.setConfig(guildId, { ...(config || {}), language: chosen });

    const embed = new EmbedBuilder()
      .setDescription(t(guildId, 'lang_set'))
      .setColor('#5865F2');

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
