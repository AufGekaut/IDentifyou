const {
  EmbedBuilder,
  AttachmentBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const db    = require('../db');
const { t } = require('../i18n');
const { generateCode, renderCaptcha } = require('../captcha');

const MAX_ATTEMPTS = parseInt(process.env.CAPTCHA_MAX_ATTEMPTS) || 3;
const EXPIRE_MS    = (parseInt(process.env.CAPTCHA_EXPIRE_MINUTES) || 5) * 60 * 1000;

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {

    // ── Slash commands ────────────────────────────────────────────────────────
    if (interaction.isChatInputCommand()) {
      const cmd = client.commands.get(interaction.commandName);
      if (!cmd) return;
      try {
        await cmd.execute(interaction, client);
      } catch (err) {
        console.error(err);
        const gid = interaction.guild?.id;
        const msg = { content: gid ? t(gid, 'verify_generic_error') : '❌ An error occurred.', ephemeral: true };
        if (interaction.deferred || interaction.replied) {
          await interaction.editReply(msg).catch(() => {});
        } else {
          await interaction.reply(msg).catch(() => {});
        }
      }
      return;
    }

    // ── Button: start_verify ──────────────────────────────────────────────────
    if (interaction.isButton() && interaction.customId === 'start_verify') {
      const gid    = interaction.guild.id;
      const config = db.getConfig(gid);

      if (!config) {
        return interaction.reply({ content: t(gid, 'verify_not_setup'), ephemeral: true });
      }

      const member = interaction.member;

      if (member.roles.cache.has(config.verifiedRoleId)) {
        return interaction.reply({ content: t(gid, 'verify_already'), ephemeral: true });
      }

      const existing = db.getSession(interaction.user.id);
      if (existing) {
        return interaction.reply({ content: t(gid, 'verify_active_session'), ephemeral: true });
      }

      // Generate CAPTCHA
      const code        = generateCode();
      const imageBuffer = renderCaptcha(code);
      const attachment  = new AttachmentBuilder(imageBuffer, { name: 'captcha.png' });
      const expiresAt   = Date.now() + EXPIRE_MS;

      db.setSession(interaction.user.id, {
        code,
        attempts:  0,
        expiresAt,
        guildId:   gid,
        startedAt: Date.now(),
      });

      const captchaEmbed = new EmbedBuilder()
        .setTitle(t(gid, 'captcha_title'))
        .setDescription(
          t(gid, 'captcha_desc')
          + `\n\n${t(gid, 'verify_expires')} <t:${Math.floor(expiresAt / 1000)}:R>`
          + (MAX_ATTEMPTS > 0 ? t(gid, 'captcha_attempts', { n: MAX_ATTEMPTS }) : '')
        )
        .setImage('attachment://captcha.png')
        .setColor('#5865F2');

      const answerBtn = new ButtonBuilder()
        .setCustomId('answer_captcha')
        .setLabel(t(gid, 'captcha_btn_answer'))
        .setStyle(ButtonStyle.Primary);

      const row = new ActionRowBuilder().addComponents(answerBtn);

      // DM first, fallback ephemeral
      let sentViaDM = false;
      try {
        const dm = await interaction.user.createDM();
        await dm.send({ embeds: [captchaEmbed], files: [attachment], components: [row] });
        sentViaDM = true;
      } catch {}

      if (sentViaDM) {
        await interaction.reply({ content: t(gid, 'verify_dm_sent'), ephemeral: true });
      } else {
        await interaction.reply({
          content: t(gid, 'verify_dm_failed'),
          embeds: [captchaEmbed],
          files: [attachment],
          components: [row],
          ephemeral: true,
        });
      }
      return;
    }

    // ── Button: answer_captcha → show modal ───────────────────────────────────
    if (interaction.isButton() && interaction.customId === 'answer_captcha') {
      const session = db.getSession(interaction.user.id);
      const gid     = session?.guildId || interaction.guild?.id;

      if (!session) {
        return interaction.reply({
          content: gid ? t(gid, 'verify_no_session') : '❌ No active CAPTCHA session.',
          ephemeral: true,
        });
      }

      const modal = new ModalBuilder()
        .setCustomId('captcha_modal')
        .setTitle(t(gid, 'captcha_modal_title'));

      const input = new TextInputBuilder()
        .setCustomId('captcha_input')
        .setLabel(t(gid, 'captcha_input_label'))
        .setStyle(TextInputStyle.Short)
        .setMinLength(1)
        .setMaxLength(10)
        .setRequired(true)
        .setPlaceholder(t(gid, 'captcha_input_ph'));

      modal.addComponents(new ActionRowBuilder().addComponents(input));
      await interaction.showModal(modal);
      return;
    }

    // ── Modal: captcha_modal ──────────────────────────────────────────────────
    if (interaction.isModalSubmit() && interaction.customId === 'captcha_modal') {
      const session = db.getSession(interaction.user.id);
      const gid     = session?.guildId || interaction.guild?.id;

      if (!session) {
        return interaction.reply({
          content: gid ? t(gid, 'verify_timeout') : '⏰ CAPTCHA expired.',
          ephemeral: true,
        });
      }

      const answer      = interaction.fields.getTextInputValue('captcha_input').toUpperCase().trim();
      const newAttempts = session.attempts + 1;

      if (answer !== session.code) {
        db.incrementFailed(gid);

        const attemptsLeft = MAX_ATTEMPTS > 0 ? MAX_ATTEMPTS - newAttempts : null;

        if (MAX_ATTEMPTS > 0 && newAttempts >= MAX_ATTEMPTS) {
          db.deleteSession(interaction.user.id);
          return interaction.reply({
            embeds: [new EmbedBuilder()
              .setDescription(t(gid, 'verify_max_attempts'))
              .setColor('#ED4245')],
            ephemeral: true,
          });
        }

        // New CAPTCHA for retry
        const newCode    = generateCode();
        const newImage   = renderCaptcha(newCode);
        const attachment = new AttachmentBuilder(newImage, { name: 'captcha.png' });

        db.updateSession(interaction.user.id, { code: newCode, attempts: newAttempts });

        const failEmbed = new EmbedBuilder()
          .setTitle(t(gid, 'verify_fail_title'))
          .setDescription(
            t(gid, 'verify_fail')
            + (attemptsLeft !== null ? t(gid, 'verify_attempts_left', { n: attemptsLeft }) : '')
            + `\n${t(gid, 'verify_expires')} <t:${Math.floor(session.expiresAt / 1000)}:R>`
          )
          .setImage('attachment://captcha.png')
          .setColor('#ED4245');

        await interaction.reply({
          embeds: [failEmbed],
          files: [attachment],
          components: [new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId('answer_captcha')
              .setLabel(t(gid, 'captcha_btn_answer'))
              .setStyle(ButtonStyle.Primary)
          )],
          ephemeral: true,
        });
        return;
      }

      // ✅ Correct!
      db.deleteSession(interaction.user.id);

      const guild = client.guilds.cache.get(session.guildId);
      if (!guild) return interaction.reply({ content: t(gid, 'verify_guild_error'), ephemeral: true });

      const config = db.getConfig(session.guildId);
      if (!config) return interaction.reply({ content: t(gid, 'verify_config_error'), ephemeral: true });

      let member;
      try {
        member = await guild.members.fetch(interaction.user.id);
      } catch {
        return interaction.reply({ content: t(gid, 'verify_member_error'), ephemeral: true });
      }

      try {
        await member.roles.add(config.verifiedRoleId, 'Passed CAPTCHA verification');
      } catch (err) {
        console.error('Failed to add verified role:', err);
        return interaction.reply({ content: t(gid, 'verify_role_error'), ephemeral: true });
      }

      if (config.unverifiedRoleId && member.roles.cache.has(config.unverifiedRoleId)) {
        await member.roles.remove(config.unverifiedRoleId).catch(() => {});
      }

      db.incrementVerified(session.guildId, interaction.user.id);

      await interaction.reply({
        embeds: [new EmbedBuilder()
          .setDescription(t(gid, 'verify_success'))
          .setColor('#57F287')],
        ephemeral: true,
      });

      // Log
      if (config.logChannelId) {
        const logChannel = guild.channels.cache.get(config.logChannelId);
        if (logChannel) {
          const stats = db.getStats(session.guildId);
          await logChannel.send({
            embeds: [new EmbedBuilder()
              .setTitle(t(gid, 'log_title'))
              .setColor('#57F287')
              .setThumbnail(interaction.user.displayAvatarURL())
              .addFields(
                { name: t(gid, 'log_user'),     value: `${interaction.user} (${interaction.user.tag})`, inline: true },
                { name: t(gid, 'log_id'),        value: interaction.user.id,  inline: true },
                { name: t(gid, 'log_attempts'),  value: `${newAttempts}`,     inline: true },
                { name: t(gid, 'log_total'),     value: `${stats.total}`,     inline: true },
              )
              .setTimestamp()],
          }).catch(() => {});
        }
      }
    }
  },
};
