const { getConfig } = require('../db');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member, client) {
    const config = getConfig(member.guild.id);
    if (!config || !config.unverifiedRoleId) return;

    try {
      await member.roles.add(config.unverifiedRoleId, 'New member - not yet verified');
    } catch (err) {
      console.error(`Failed to assign unverified role to ${member.user.tag}:`, err.message);
    }
  },
};
