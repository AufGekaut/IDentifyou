const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'clientReady',
  once: true,
  async execute(client) {
    console.log(`✅ Logged in as ${client.user.tag}`);

    // Register slash commands globally
    const commands = [];
    const commandsPath = path.join(__dirname, '..', 'commands');
    for (const file of fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'))) {
      const cmd = require(path.join(commandsPath, file));
      if (cmd.data) commands.push(cmd.data.toJSON());
    }

    const rest = new REST().setToken(process.env.TOKEN);
    try {
      await rest.put(Routes.applicationCommands(client.user.id), { body: commands });
      console.log(`📡 Registered ${commands.length} slash command(s) globally`);
    } catch (err) {
      console.error('Failed to register commands:', err);
    }

    client.user.setActivity('🔐 Protecting the server');
  },
};
