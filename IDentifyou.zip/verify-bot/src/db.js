/**
 * db.js — Zentrale persistente Datenbank (db.json)
 *
 * Struktur der db.json:
 * {
 *   "guilds": {
 *     "<guildId>": { ...GuildConfig }
 *   },
 *   "sessions": {
 *     "<userId>": { code, attempts, expiresAt, guildId, startedAt }
 *   },
 *   "stats": {
 *     "<guildId>": { total: 0, failed: 0, lastVerified: null }
 *   }
 * }
 */

const fs   = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, '..', 'db.json');
const TMP_FILE = DB_FILE + '.tmp'; // atomares Schreiben

// ── Defaults ────────────────────────────────────────────────────────────────
const DEFAULT_DB = {
  guilds:   {},
  sessions: {},
  stats:    {},
};

// ── Init ─────────────────────────────────────────────────────────────────────
let _db = DEFAULT_DB;

function _load() {
  if (!fs.existsSync(DB_FILE)) {
    _db = structuredClone(DEFAULT_DB);
    _write(); // erstelle leere db.json
    return;
  }
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf8');
    _db = { ...DEFAULT_DB, ...JSON.parse(raw) };
    // Sicherstellen dass alle Keys vorhanden
    _db.guilds   = _db.guilds   || {};
    _db.sessions = _db.sessions || {};
    _db.stats    = _db.stats    || {};
    console.log(`[DB] Loaded db.json — ${Object.keys(_db.guilds).length} guild(s), ${Object.keys(_db.sessions).length} session(s)`);
  } catch (err) {
    console.error('[DB] Failed to parse db.json, starting fresh:', err.message);
    _db = structuredClone(DEFAULT_DB);
  }
}

/** Atomares Schreiben: erst tmp, dann rename — verhindert Datei-Korruption bei Absturz */
function _write() {
  try {
    const data = JSON.stringify(_db, null, 2);
    fs.writeFileSync(TMP_FILE, data, 'utf8');
    fs.renameSync(TMP_FILE, DB_FILE);
  } catch (err) {
    console.error('[DB] Write error:', err.message);
  }
}

// Beim Start laden
_load();

// ── Guild Config ─────────────────────────────────────────────────────────────

/** @returns {object|null} */
function getConfig(guildId) {
  return _db.guilds[guildId] || null;
}

/** Speichert / überschreibt die Config einer Guild */
function setConfig(guildId, config) {
  _db.guilds[guildId] = { ...config, updatedAt: Date.now() };
  _write();
}

/** Löscht die Config einer Guild */
function deleteConfig(guildId) {
  delete _db.guilds[guildId];
  _write();
}

// ── CAPTCHA Sessions ──────────────────────────────────────────────────────────

/** @returns {object|null} */
function getSession(userId) {
  const s = _db.sessions[userId];
  if (!s) return null;
  // Bereits abgelaufen?
  if (Date.now() > s.expiresAt) {
    deleteSession(userId);
    return null;
  }
  return s;
}

/** Legt eine neue CAPTCHA-Session an oder überschreibt eine bestehende */
function setSession(userId, sessionData) {
  _db.sessions[userId] = { ...sessionData, savedAt: Date.now() };
  _write();
}

/** Aktualisiert einzelne Felder einer Session (z.B. code, attempts) */
function updateSession(userId, patch) {
  if (!_db.sessions[userId]) return;
  _db.sessions[userId] = { ..._db.sessions[userId], ...patch };
  _write();
}

/** Löscht eine Session */
function deleteSession(userId) {
  if (!_db.sessions[userId]) return;
  delete _db.sessions[userId];
  _write();
}

/** Entfernt alle abgelaufenen Sessions — sollte periodisch aufgerufen werden */
function cleanupSessions() {
  const now = Date.now();
  let removed = 0;
  for (const userId of Object.keys(_db.sessions)) {
    if (now > _db.sessions[userId].expiresAt) {
      delete _db.sessions[userId];
      removed++;
    }
  }
  if (removed > 0) {
    _write();
    console.log(`[DB] Cleaned up ${removed} expired session(s)`);
  }
}

// ── Stats ─────────────────────────────────────────────────────────────────────

function getStats(guildId) {
  return _db.stats[guildId] || { total: 0, failed: 0, lastVerified: null };
}

function incrementVerified(guildId, userId) {
  if (!_db.stats[guildId]) _db.stats[guildId] = { total: 0, failed: 0, lastVerified: null };
  _db.stats[guildId].total++;
  _db.stats[guildId].lastVerified = { userId, at: Date.now() };
  _write();
}

function incrementFailed(guildId) {
  if (!_db.stats[guildId]) _db.stats[guildId] = { total: 0, failed: 0, lastVerified: null };
  _db.stats[guildId].failed++;
  _write();
}

// ── Utilities ─────────────────────────────────────────────────────────────────

/** Gibt die rohe DB zurück (z.B. für Debug) */
function getRawDb() {
  return _db;
}

module.exports = {
  // Guild
  getConfig,
  setConfig,
  deleteConfig,
  // Sessions
  getSession,
  setSession,
  updateSession,
  deleteSession,
  cleanupSessions,
  // Stats
  getStats,
  incrementVerified,
  incrementFailed,
  // Debug
  getRawDb,
};
