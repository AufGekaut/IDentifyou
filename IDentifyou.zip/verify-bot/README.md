# 🔐 Discord Verify Bot

Ein vollständiger Discord Verification Bot mit Bild-CAPTCHA, automatischer Channel/Rollen-Erstellung und vollständiger Anpassbarkeit.

---

## ✨ Features

- 🖼️ **Bild-CAPTCHA** — Verzerrter Text, Rauschen, Farben → keine simplen Bots kommen durch
- 🔘 **Button → Modal-Flow** — kein Slash-Spam, saubere UX
- 📬 **DM-first** — CAPTCHA wird per DM gesendet, Fallback auf Ephemeral
- 🔒 **Auto-Channel-Lock** — setzt automatisch `@everyone ViewChannel: off` auf Channels ohne Rollen-Overrides
- 🎭 **Auto-Rollen** — erstellt `Verified` / `Unverified` falls nicht angegeben
- 📋 **Log-Channel** — protokolliert jede Verifizierung
- ⚙️ **Vollständig customizebar** — per `.env` oder `/setup`-Optionen
- ♻️ **Session-Management** — Ablauf-Timer, max. Versuche, automatisches Cleanup

---

## 🚀 Installation

### 1. Repository klonen / Dateien kopieren

```bash
git clone <repo> verify-bot
cd verify-bot
```

### 2. Dependencies installieren

```bash
npm install
```

> **Hinweis:** `canvas` benötigt native Build-Tools:
> - **Ubuntu/Debian:** `sudo apt install build-essential libcairo2-dev libpango1.0-dev libjpeg-dev libgif-dev librsvg2-dev`
> - **Windows:** [node-canvas Wiki](https://github.com/Automattic/node-canvas/wiki/Installation:-Windows)

### 3. `.env` konfigurieren

```env
TOKEN=dein_bot_token
CLIENT_ID=deine_application_id
```

Alle weiteren Einstellungen sind optional und haben sinnvolle Defaults.

### 4. Bot starten

```bash
npm start
# oder für Entwicklung:
npm run dev
```

---

## ⚙️ `.env` Referenz

| Variable | Default | Beschreibung |
|---|---|---|
| `TOKEN` | — | **Pflicht.** Bot-Token |
| `CLIENT_ID` | — | **Pflicht.** Application-ID |
| `CAPTCHA_LENGTH` | `6` | Anzahl Zeichen im CAPTCHA |
| `CAPTCHA_EXPIRE_MINUTES` | `5` | Minuten bis CAPTCHA abläuft |
| `CAPTCHA_MAX_ATTEMPTS` | `3` | Max. Fehlversuche (0 = unbegrenzt) |
| `EMBED_COLOR` | `#5865F2` | Farbe des Verify-Embeds |
| `EMBED_TITLE` | `🔐 Server Verification` | Titel |
| `EMBED_DESCRIPTION` | *(Standardtext)* | Beschreibungstext |
| `EMBED_FOOTER` | `Verification powered by VerifyBot` | Footer |
| `EMBED_THUMBNAIL` | *(leer)* | Thumbnail-URL |
| `BUTTON_LABEL` | `✅ Verify me` | Button-Beschriftung |
| `BUTTON_COLOR` | `Success` | `Primary`/`Secondary`/`Success`/`Danger` |
| `MSG_SUCCESS` | *(Standardtext)* | Nachricht bei Erfolg |
| `MSG_FAIL` | *(Standardtext)* | Nachricht bei falschem CAPTCHA |
| `MSG_TIMEOUT` | *(Standardtext)* | Nachricht bei Ablauf |
| `MSG_MAX_ATTEMPTS` | *(Standardtext)* | Nachricht bei zu vielen Versuchen |

---

## 🛠️ Commands

### `/setup` *(Admin)*
Richtet das Verify-System ein.

| Option | Typ | Beschreibung |
|---|---|---|
| `channel` | Channel | Bestehender Channel für das Panel (leer = auto) |
| `verified_role` | Rolle | Rolle nach Verifizierung (leer = auto) |
| `unverified_role` | Rolle | Rolle für neue Member (leer = auto) |
| `log_channel` | Channel | Log-Channel (leer = auto) |
| `embed_title` | Text | Embed-Titel |
| `embed_description` | Text | Embed-Beschreibung |
| `embed_color` | Text | Hex-Farbe z.B. `#FF5733` |
| `button_label` | Text | Button-Text |
| `button_color` | Auswahl | Blau / Grau / Grün / Rot |

**Nur `/setup` ohne Optionen** → alles wird automatisch erstellt!

### `/status` *(Admin)*
Zeigt die aktuelle Konfiguration an.

### `/reset` *(Admin)*
Löscht die gespeicherte Konfiguration (Channels/Rollen bleiben erhalten).

---

## 🔒 Wie Channel-Locking funktioniert

Beim `/setup` durchsucht der Bot **alle Text- und Voice-Channels**:
- Hat der Channel **keine Rollen-Overrides** (nur @everyone oder nichts)?
- Kann @everyone den Channel sehen?

Wenn ja → `@everyone ViewChannel: false` + `Verified ViewChannel: true` wird gesetzt.

Channels mit bestehenden Rollen-Konfigurationen werden **nicht** angefasst.

---

## 📁 Dateistruktur

```
verify-bot/
├── src/
│   ├── index.js          # Bot-Einstiegspunkt
│   ├── captcha.js        # CAPTCHA-Generator
│   ├── store.js          # Persistente Guild-Config (JSON)
│   ├── commands/
│   │   ├── setup.js      # /setup Command
│   │   ├── reset.js      # /reset Command
│   │   └── status.js     # /status Command
│   └── events/
│       ├── ready.js          # Bot ready, Commands registrieren
│       ├── interactionCreate.js  # Button/Modal-Handler
│       └── guildMemberAdd.js # Neue Member → Unverified-Rolle
├── data/
│   └── guilds.json       # Gespeicherte Guild-Configs
├── .env                  # Konfiguration
├── package.json
└── README.md
```

---

## 🤖 Bot-Berechtigungen

Der Bot benötigt folgende Permissions:
- `Manage Roles`
- `Manage Channels`
- `Send Messages`
- `Embed Links`
- `Attach Files`
- `Read Message History`
- `View Channels`

**Wichtig:** Die Bot-Rolle muss **über** der `Verified`- und `Unverified`-Rolle in der Rollenhierarchie stehen!

---

## 📦 Auf dem VPS deployen (PM2)

```bash
npm install -g pm2
pm2 start src/index.js --name verify-bot
pm2 save
pm2 startup
```
